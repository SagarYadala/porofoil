import { Skill } from '../types';

export const skills: Skill[] = [
  {
    name: 'Docker',
    icon: 'container',
    category: 'Containerization',
    proficiency: 90,
  },
  {
    name: 'Kubernetes',
    icon: 'binary',
    category: 'Containerization',
    proficiency: 75,
  },
  {
    name: 'Jenkins',
    icon: 'workflow',
    category: 'CI/CD',
    proficiency: 85,
  },
  {
    name: 'GitHub Actions',
    icon: 'git-branch',
    category: 'CI/CD',
    proficiency: 90,
  },
  {
    name: 'AWS',
    icon: 'cloud',
    category: 'Cloud',
    proficiency: 80,
  },
  {
    name: 'Azure',
    icon: 'cloud',
    category: 'Cloud',
    proficiency: 70,
  },
  {
    name: 'Terraform',
    icon: 'boxes',
    category: 'Infrastructure as Code',
    proficiency: 85,
  },
  {
    name: 'Ansible',
    icon: 'settings',
    category: 'Infrastructure as Code',
    proficiency: 75,
  },
  {
    name: 'Prometheus',
    icon: 'bar-chart',
    category: 'Monitoring',
    proficiency: 70,
  },
  {
    name: 'Grafana',
    icon: 'line-chart',
    category: 'Monitoring',
    proficiency: 65,
  },
  {
    name: 'Python',
    icon: 'code',
    category: 'Scripting',
    proficiency: 85,
  },
  {
    name: 'Bash',
    icon: 'terminal',
    category: 'Scripting',
    proficiency: 90,
  },
];