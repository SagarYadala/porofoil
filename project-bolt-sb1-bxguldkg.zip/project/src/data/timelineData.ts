import { TimelineItem } from '../types';

export const timelineItems: TimelineItem[] = [
  {
    title: 'Bachelor of Technology',
    organization: 'KL University',
    date: '2019 - 2023',
    description: 'Completed B.Tech with a focus on computer science fundamentals, software engineering, and cloud computing technologies.',
    tags: ['Cloud Computing', 'Software Engineering', 'DevOps'],
    type: 'education',
  },
  {
    title: 'AWS Certified Cloud Practitioner',
    date: 'December 2023',
    description: 'Achieved AWS Cloud Practitioner certification, demonstrating understanding of AWS Cloud concepts, services, and best practices.',
    type: 'certification',
  },
  {
    title: 'DevOps Training Program',
    organization: 'Tech Academy',
    date: 'June 2023 - August 2023',
    description: 'Completed intensive training in DevOps practices, including CI/CD pipelines, containerization, and infrastructure automation.',
    tags: ['Jenkins', 'Docker', 'Kubernetes', 'Terraform'],
    type: 'certification',
  },
  {
    title: 'Cloud Infrastructure Project',
    organization: 'University Project',
    date: 'January 2023 - April 2023',
    description: 'Led a team project to design and implement a scalable cloud infrastructure using AWS services and Infrastructure as Code.',
    tags: ['AWS', 'Terraform', 'Docker', 'CI/CD'],
    type: 'experience',
  },
];