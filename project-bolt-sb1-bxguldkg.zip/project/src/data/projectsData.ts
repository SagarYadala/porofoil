import { Project } from '../types';

export const projects: Project[] = [
  {
    id: 'ci-cd-pipeline',
    title: 'Automated CI/CD Pipeline',
    description: 'Designed and implemented a comprehensive CI/CD pipeline using Jenkins, Docker, and GitHub Actions. The pipeline automates testing, building, and deployment processes for a microservices architecture.',
    image: 'https://images.pexels.com/photos/1181271/pexels-photo-1181271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    technologies: ['Jenkins', 'Docker', 'GitHub Actions', 'AWS', 'Bash'],
    github: 'https://github.com/johndoe/ci-cd-pipeline',
  },
  {
    id: 'k8s-infrastructure',
    title: 'Kubernetes Cluster Setup',
    description: 'Created a production-ready Kubernetes cluster with high availability and disaster recovery capabilities. Implemented automated scaling, monitoring, and alerting systems.',
    image: 'https://images.pexels.com/photos/8817455/pexels-photo-8817455.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    technologies: ['Kubernetes', 'Helm', 'Terraform', 'Prometheus', 'Grafana'],
    github: 'https://github.com/johndoe/k8s-infrastructure',
  },
  {
    id: 'iac-templates',
    title: 'Infrastructure as Code Templates',
    description: 'Developed reusable IaC templates for quick deployment of standardized infrastructure components across multiple cloud providers. Includes modules for networking, compute, storage, and security.',
    image: 'https://images.pexels.com/photos/4164418/pexels-photo-4164418.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    technologies: ['Terraform', 'AWS', 'Azure', 'CloudFormation', 'Python'],
    github: 'https://github.com/johndoe/iac-templates',
  },
  {
    id: 'monitoring-stack',
    title: 'Cloud Monitoring Solution',
    description: 'Built a comprehensive monitoring and alerting system for cloud infrastructure using open-source tools. Features custom dashboards, automated alerts, and detailed performance metrics.',
    image: 'https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    technologies: ['Prometheus', 'Grafana', 'ELK Stack', 'AWS CloudWatch', 'Python'],
    github: 'https://github.com/johndoe/monitoring-stack',
  },
];