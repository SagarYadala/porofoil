import { NavItem } from '../types';

export const navItems: NavItem[] = [
  {
    label: 'Home',
    href: '#home',
  },
  {
    label: 'Skills',
    href: '#skills',
  },
  {
    label: 'Projects',
    href: '#projects',
  },
  {
    label: 'Experience',
    href: '#experience',
  },
  {
    label: 'Contact',
    href: '#contact',
  },
];