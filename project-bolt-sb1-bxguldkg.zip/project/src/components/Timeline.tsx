import React from 'react';
import { timelineItems } from '../data/timelineData';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { GraduationCap, Award, Briefcase } from 'lucide-react';
import AnimatedSection from './AnimatedSection';

interface TimelineItemProps {
  title: string;
  organization?: string;
  date: string;
  description: string;
  tags?: string[];
  type: 'education' | 'experience' | 'certification';
  index: number;
  isLast: boolean;
}

const TimelineItemComponent: React.FC<TimelineItemProps> = ({
  title,
  organization,
  date,
  description,
  tags,
  type,
  index,
  isLast,
}) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  let Icon;
  let iconColor;

  switch (type) {
    case 'education':
      Icon = GraduationCap;
      iconColor = 'text-blue-500 dark:text-blue-400';
      break;
    case 'certification':
      Icon = Award;
      iconColor = 'text-yellow-500 dark:text-yellow-400';
      break;
    case 'experience':
      Icon = Briefcase;
      iconColor = 'text-teal-500 dark:text-teal-400';
      break;
  }

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="grid grid-cols-[1fr_auto_1fr] gap-4 mb-8"
    >
      <div className={`text-right ${index % 2 === 0 ? '' : 'order-3'}`}>
        {index % 2 === 0 ? (
          <>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
              {title}
            </h3>
            {organization && (
              <p className="text-gray-700 dark:text-gray-300 mb-1">{organization}</p>
            )}
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">{date}</p>
            <p className="text-gray-700 dark:text-gray-300 mb-3">{description}</p>
            {tags && (
              <div className="flex flex-wrap gap-2 justify-end">
                {tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-2 py-1 text-xs bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            )}
          </>
        ) : null}
      </div>

      <div className="flex flex-col items-center">
        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
          type === 'education' 
            ? 'bg-blue-100 dark:bg-blue-900/30' 
            : type === 'certification' 
              ? 'bg-yellow-100 dark:bg-yellow-900/30' 
              : 'bg-teal-100 dark:bg-teal-900/30'
        }`}>
          <Icon className={`w-5 h-5 ${iconColor}`} />
        </div>
        {!isLast && (
          <div className="w-0.5 bg-gray-300 dark:bg-gray-700 grow mt-2"></div>
        )}
      </div>

      <div className={index % 2 === 0 ? 'order-3' : ''}>
        {index % 2 !== 0 ? (
          <>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
              {title}
            </h3>
            {organization && (
              <p className="text-gray-700 dark:text-gray-300 mb-1">{organization}</p>
            )}
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">{date}</p>
            <p className="text-gray-700 dark:text-gray-300 mb-3">{description}</p>
            {tags && (
              <div className="flex flex-wrap gap-2">
                {tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-2 py-1 text-xs bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            )}
          </>
        ) : null}
      </div>
    </motion.div>
  );
};

const Timeline: React.FC = () => {
  const sortedItems = [...timelineItems].sort((a, b) => {
    // Extract years for comparison
    const yearA = parseInt(a.date.split(' ').pop() || '0');
    const yearB = parseInt(b.date.split(' ').pop() || '0');
    return yearB - yearA; // Newest first
  });

  return (
    <section id="experience" className="py-16 md:py-24 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4 md:px-6">
        <AnimatedSection className="mb-12 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Experience & Education
          </h2>
          <p className="text-lg text-gray-700 dark:text-gray-300 max-w-3xl mx-auto">
            My academic journey, professional experiences, and certifications in the DevOps field.
          </p>
        </AnimatedSection>

        <div className="max-w-4xl mx-auto mt-16">
          {sortedItems.map((item, index) => (
            <TimelineItemComponent
              key={`${item.title}-${index}`}
              title={item.title}
              organization={item.organization}
              date={item.date}
              description={item.description}
              tags={item.tags}
              type={item.type}
              index={index}
              isLast={index === sortedItems.length - 1}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Timeline;