import React from 'react';
import { skills } from '../data/skillsData';
import { useInView } from 'react-intersection-observer';
import { motion } from 'framer-motion';
import * as LucideIcons from 'lucide-react';
import AnimatedSection from './AnimatedSection';

interface SkillCardProps {
  name: string;
  icon: string;
  proficiency: number;
  index: number;
}

const SkillCard: React.FC<SkillCardProps> = ({ name, icon, proficiency, index }) => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  // @ts-ignore - Dynamically access Lucide icons
  const IconComponent = LucideIcons[icon.charAt(0).toUpperCase() + icon.slice(1)] || LucideIcons.Code;

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-md hover:shadow-lg transition-all duration-300 border border-gray-100 dark:border-gray-700"
    >
      <div className="flex items-center mb-4">
        <div className="p-3 bg-teal-100 dark:bg-teal-900/30 rounded-full mr-4">
          <IconComponent className="w-6 h-6 text-teal-600 dark:text-teal-400" />
        </div>
        <h3 className="font-semibold text-lg text-gray-900 dark:text-white">
          {name}
        </h3>
      </div>
      <div className="relative h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={inView ? { width: `${proficiency}%` } : { width: 0 }}
          transition={{ duration: 1, delay: index * 0.1 + 0.3 }}
          className="absolute h-full bg-gradient-to-r from-teal-500 to-teal-600 rounded-full"
        />
      </div>
      <div className="mt-2 text-right text-sm text-gray-600 dark:text-gray-400">
        {proficiency}%
      </div>
    </motion.div>
  );
};

const Skills: React.FC = () => {
  // Group skills by category
  const skillsByCategory = skills.reduce((acc, skill) => {
    if (!acc[skill.category]) {
      acc[skill.category] = [];
    }
    acc[skill.category].push(skill);
    return acc;
  }, {} as Record<string, typeof skills>);

  return (
    <section id="skills" className="py-16 md:py-24 bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4 md:px-6">
        <AnimatedSection className="mb-12 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Technical Skills
          </h2>
          <p className="text-lg text-gray-700 dark:text-gray-300 max-w-3xl mx-auto">
            My expertise spans across various DevOps tools and technologies that help
            automate workflows and improve software delivery.
          </p>
        </AnimatedSection>

        <div className="space-y-10">
          {Object.entries(skillsByCategory).map(([category, categorySkills], categoryIndex) => (
            <div key={category} className="mt-12">
              <AnimatedSection 
                className="mb-6" 
                delay={categoryIndex * 0.2}
              >
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2 flex items-center">
                  <span className="inline-block w-6 h-0.5 bg-teal-500 mr-3"></span>
                  {category}
                </h3>
              </AnimatedSection>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {categorySkills.map((skill, index) => (
                  <SkillCard
                    key={skill.name}
                    name={skill.name}
                    icon={skill.icon}
                    proficiency={skill.proficiency}
                    index={index}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;