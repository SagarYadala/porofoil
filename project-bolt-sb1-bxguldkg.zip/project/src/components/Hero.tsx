import React from 'react';
import { motion } from 'framer-motion';
import { Download, ArrowDown } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section id="home" className="pt-28 pb-16 md:pt-36 md:pb-24 overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-12 md:mb-0">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <h2 className="text-sm font-semibold text-teal-600 dark:text-teal-400 uppercase tracking-wider mb-3">
                DevOps Engineer
              </h2>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 dark:text-white mb-6 leading-tight">
                Building the Future <span className="text-teal-600 dark:text-teal-400">Through DevOps</span> Innovation
              </h1>
              <p className="text-lg text-gray-700 dark:text-gray-300 mb-8 max-w-2xl">
                Fresh DevOps engineer with a strong foundation in CI/CD pipelines, 
                containerization, and cloud infrastructure. Passionate about automating 
                processes and implementing efficient deployment strategies.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <a
                  href="#projects"
                  className="px-6 py-3 bg-teal-600 hover:bg-teal-700 text-white rounded-md transition-colors duration-200 text-center"
                >
                  View Projects
                </a>
                <a
                  href="/sagar-yadala-resume.pdf"
                  className="px-6 py-3 border border-gray-300 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-800 dark:text-gray-200 rounded-md transition-colors duration-200 flex items-center justify-center"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download Resume
                </a>
              </div>
            </motion.div>
          </div>
          <div className="md:w-1/2">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="relative"
            >
              <div className="w-full h-full absolute -inset-1 bg-gradient-to-r from-teal-500 to-blue-500 rounded-lg blur-md opacity-70 dark:opacity-50 animate-pulse"></div>
              <div className="relative bg-white dark:bg-gray-800 p-5 rounded-lg shadow-xl">
                <div className="flex items-center space-x-2 mb-4">
                  <div className="w-3 h-3 rounded-full bg-red-500"></div>
                  <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  <div className="ml-2 text-sm text-gray-500 dark:text-gray-400 font-mono">~/devops-pipeline</div>
                </div>
                <pre className="bg-gray-900 p-4 rounded text-green-400 font-mono text-sm overflow-x-auto">
                  <code>{`$ docker-compose up -d
Creating network "app_default" with driver "bridge"
Creating volume "app_data" with local driver
Creating app_db_1    ... done
Creating app_redis_1 ... done
Creating app_api_1   ... done
Creating app_web_1   ... done

$ kubectl get pods
NAME                         READY   STATUS    RESTARTS   AGE
api-deployment-6d5f8c8d7f-xj2vn   1/1     Running   0          2m
web-deployment-7f9c7bc5c6-t6v8p   1/1     Running   0          2m

$ terraform apply
Apply complete! Resources: 12 added, 0 changed, 0 destroyed.

Outputs:
load_balancer_ip = "13.235.42.157"
`}</code>
                </pre>
              </div>
            </motion.div>
          </div>
        </div>
        <div className="flex justify-center mt-16">
          <motion.a
            href="#skills"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.8 }}
            className="flex flex-col items-center text-gray-500 dark:text-gray-400 hover:text-teal-600 dark:hover:text-teal-400 transition-colors duration-200"
          >
            <span className="mb-2 text-sm">Scroll to Explore</span>
            <ArrowDown className="w-5 h-5 animate-bounce" />
          </motion.a>
        </div>
      </div>
    </section>
  );
};

export default Hero;