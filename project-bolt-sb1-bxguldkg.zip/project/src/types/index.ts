export interface NavItem {
  label: string;
  href: string;
}

export interface Skill {
  name: string;
  icon: string;
  category: 'CI/CD' | 'Cloud' | 'Containerization' | 'Infrastructure as Code' | 'Monitoring' | 'Scripting';
  proficiency: number;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  image: string;
  technologies: string[];
  link?: string;
  github?: string;
}

export interface TimelineItem {
  title: string;
  organization?: string;
  date: string;
  description: string;
  tags?: string[];
  type: 'education' | 'experience' | 'certification';
}

export interface ThemeContextType {
  isDarkMode: boolean;
  toggleTheme: () => void;
}